function buscaW(query){
jQuery.ajax({
        url: "mysqlexecuta.php",
        type: "POST",
        data: {"consulta":consulta},
        dataType: 'json',
		error: function(){
			alert('erro');
		},
        beforeSend: function(){
            jQuery("body").css("cursor", "progress");
        },
        success: function(response) {
                        jQuery("#exibeResult").html(response);
        },
        complete: function(){
            jQuery("body").css("cursor", "auto");
        }
    });
	//alert(response.urls);
}