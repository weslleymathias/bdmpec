<!DOCTYPE html>
<html lang="en">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Submeter Produto</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/logo-nav.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        <link rel="stylesheet" type="text/css" href="css/Acesso_Acervo.css">
        <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
        <script src="script.js"></script>
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
    </head>

    <body>

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <img src="img/logompec.png" alt="">
                    </a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li><a href='submeter.html'><span>Submeter Produto</span></a></li>
                        <li><a href='produtos_submetidos.html'><span>Produtos Submetidos</span></a></li>
                        <li><a href='perfil_contribuidor.php'><span>Editar Perfil</span></a></li>  
                        <li><a href='index.html'><span>Sair</span></a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
        </nav>


        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <?php
                    session_start();
                    error_reporting(0);

                    include "mysqlconecta.php";

                    $nome_autor = $_POST['nome'];
                    $email_autor = $_POST['email'];
                    $lattes = $_POST['lattes'];
                    $orientador = $_POST['orientador'];
                    $email_orientador = $_POST['emailor'];
                    $lattes_orientador = $_POST['lattesor'];
                    $coorientador = $_POST['coorientador'];
                    $titulo = $_POST['titulo'];
                    $data = $_POST['data'];
                    $resumo = $_POST['resumo'];

                    $dis_name = $_FILES['linkdis']['name'];
                    echo "$dis_name";
                    $dis_type = $_FILES['linkdis']['type'];
                    $dis_temp = $_FILES['linkdis']['tmp_name'];
                    $dis_error = $_FILES['linkdis']['error'];

                    if ($dis_error == 0) {
                        $pasta = '/arquivos/';
                        $upload = move_uploaded_file($dis_temp, $pasta . $dis_name);
                    }

                    $palavra = $_POST['palavra'];
                    $area_pesquisa = $_POST['areapes'];
                    $ies = $_POST['ies'];
                    $rua = $_POST['rua'];
                    $numero = $_POST['numero'];
                    $cidade = $_POST['cidade'];
                    $estado = $_POST['estado'];
                    $campus = $_POST['campus'];
                    $nome_produto = $_POST['nomeprod'];
                    $tema = $_POST['tema'];
                    $descricao = $_POST['descricao'];
                    $link = $_POST['link'];
                    $colaborador = $_POST['colaborador'];
                    $area_concentracao = $_POST['area'];
                    $nivel = $_POST['nivel'];
                    $serie = $_POST['serie'];
                    $categoria = $_POST['categoria'];
                    $status = "Em analise";

                    $id_cont = $_SESSION['ContribuidorId'];

                    
                  /*  $inserir_dissertacao = "INSERT INTO dissertacao(id_dissertacao, titulo, data_defesa, resumo, link_dissertacao) VALUES(NULL, '$titulo', '$data', '$resumo', '$link_dissertacao')";
                    mysql_query($inserir_dissertacao) or die(mysql_error());

                    $buscar_dissertacao = "SELECT id_dissertacao FROM dissertacao WHERE titulo = '$titulo' AND data_defesa = '$data' AND resumo = '$resumo' AND link_dissertacao = '$link_dissertacao' ";
                    $busca_dissertacao = mysql_query($buscar_dissertacao)or die(mysql_error());

                    if($dados_dissertacao = mysql_fetch_array($busca_dissertacao)){
                        $iddis = $dados_dissertacao['id_dissertacao'];
                    }

                    foreach ($palavra as &$value) {
                        $buscar_palavra = "SELECT id_palavra FROM palavra_chave WHERE palavra = '$value' ";
                        $busca_palavra = mysql_query($buscar_palavra)or die(mysql_error());

                        if(mysql_num_rows($busca_palavra) == 0){
                            $inserir_palavra = "INSERT INTO palavra_chave(id_palavra, palavra) VALUES(NULL, '$value') ";
                            mysql_query($inserir_palavra) or die(mysql_error());

                            $buscar_palavra2 = "SELECT id_palavra FROM palavra_chave WHERE palavra = '$value' ";
                            $busca_palavra2 = mysql_query($buscar_palavra2)or die(mysql_error());

                            if ($dados_palavra = mysql_fetch_array($busca_palavra2)) {
                                $idpal = $dados_palavra['id_palavra'];
                                $inserir_dissert_palavra = "INSERT INTO dissert_palavra(id_palavra, id_dissertacao) VALUES('$idpal', '$iddis') ";
                                mysql_query($inserir_dissert_palavra) or die(mysql_error());
                            }

                        }
                        elseif ($dados_palavra = mysql_fetch_array($busca_palavra)) {
                            $idpal = $dados_palavra['id_palavra'];
                            $inserir_dissert_palavra = "INSERT INTO dissert_palavra(id_palavra, id_dissertacao) VALUES('$idpal', '$iddis') ";
                            mysql_query($inserir_dissert_palavra) or die(mysql_error());
                        }
                        
                        echo "Palavra: $value <br />";
                    }

                    //busca pelo orientador
                    $buscar_orientador = "SELECT id_pessoa FROM pessoa WHERE nome = '$orientador' AND email = '$email_orientador' AND pessoa.link_lattes = '$lattes_orientador' AND papel ='orientador' ";
                    $busca_orientador = mysql_query($buscar_orientador)or die(mysql_error());
                    
                    //se o orientador n�o existir, � adicionado e capturado seu id
                    if (mysql_num_rows($busca_orientador) == 0) { 
                        $inserir_orientador = "INSERT INTO pessoa(id_pessoa, nome, email, link_lattes, papel) VALUES(NULL, '$orientador', '$email_orientador', '$lattes_orientador', 'orientador')";
                        mysql_query($inserir_orientador) or die(mysql_error());

                        $buscar_orientador2 = "SELECT id_pessoa FROM pessoa WHERE nome = '$orientador' AND email = '$email_orientador' AND pessoa.link_lattes = '$lattes_orientador' AND papel ='orientador' ";
                        $busca_orientador2 = mysql_query($buscar_orientador)or die(mysql_error());

                        if ($dados2 = mysql_fetch_array($busca_orientador2)) {
                        $idor = $dados2['id_pessoa'];

                    }
                    }

                    //se o orientador existir, � capturado seu id
                    elseif ($dados = mysql_fetch_array($busca_orientador)) {
                        $idor = $dados['id_pessoa'];
                     
                    }

                    //busca pelo autor
                    $buscar_autor = "SELECT id_pessoa FROM pessoa WHERE nome = '$nome_autor' AND email = '$email_autor' AND pessoa.link_lattes = '$lattes' AND papel = 'autor' ";
                    $busca_autor = mysql_query($buscar_autor)or die(mysql_error());

                    //se o autor n�o existir, � adicionado e capturado seu id
                    if (mysql_num_rows($busca_autor) == 0) {
                        $inserir_autor = "INSERT INTO pessoa(id_pessoa, nome, email, link_lattes, papel) VALUES(NULL, '$nome_autor', '$email_autor', '$lattes', 'autor')";
                        mysql_query($inserir_autor) or die(mysql_error());

                        $buscar_autor2 = "SELECT id_pessoa FROM pessoa WHERE nome = '$nome_autor' AND email = '$email_autor' AND pessoa.link_lattes = '$lattes' AND papel ='autor' ";
                        $busca_autor2 = mysql_query($buscar_autor2)or die(mysql_error());

                        if ($dados_autor = mysql_fetch_array($busca_autor2)) {
                            $idau = $dados_autor['id_pessoa'];
                        }

                    }

                    //se o autor existir, � adicionado com outro orientador e � capturado seu id
                    elseif ($dados_autor = mysql_fetch_array($busca_autor)) {
                        $idau = $dados_autor['id_pessoa'];
                    }

                    echo "ID orientador: $idor<br />";
                    echo "ID autor: $idau<br />";
                    
                    //vinculando autor a area de pesquisa
                    if($area_pesquisa == 'enscie'){
                        $inserir_area_pesquisa = "INSERT INTO vinculado(id_pessoa, id_area) VALUES('$idau', 1) ";
                        mysql_query($inserir_area_pesquisa) or die(mysql_error());
                    }
                    elseif ($area_pesquisa == 'ensfis') {
                        $inserir_area_pesquisa = "INSERT INTO vinculado(id_pessoa, id_area) VALUES('$idau', 2) ";
                        mysql_query($inserir_area_pesquisa) or die(mysql_error());
                    }
                    elseif ($area_pesquisa == 'ensbio') {
                        $inserir_area_pesquisa = "INSERT INTO vinculado(id_pessoa, id_area) VALUES('$idau', 3) ";
                        mysql_query($inserir_area_pesquisa) or die(mysql_error());
                    }
                    elseif ($area_pesquisa == 'ensqui') {
                        $inserir_area_pesquisa = "INSERT INTO vinculado(id_pessoa, id_area) VALUES('$idau', 4) ";
                        mysql_query($inserir_area_pesquisa) or die(mysql_error());
                    }
                    elseif ($area_pesquisa == 'ensfis') {
                        $inserir_area_pesquisa = "INSERT INTO vinculado(id_pessoa, id_area) VALUES('$idau', 5) ";
                        mysql_query($inserir_area_pesquisa) or die(mysql_error());
                    }

                    //buscando ies
                    $buscar_ies = "SELECT id_ies FROM ies WHERE ies.nome = '$ies' ";
                    $busca_ies = mysql_query($buscar_ies)or die(mysql_error());

                    //inserindo ies
                    if(mysql_num_rows($busca_ies) == 0){
                        $inserir_ies = "INSERT INTO ies(id_ies, nome) VALUES(NULL, '$ies') ";
                        mysql_query($inserir_ies) or die(mysql_error());

                        $buscar_ies2 = "SELECT id_ies FROM ies WHERE ies.nome = '$ies' ";
                        $busca_ies2 = mysql_query($buscar_ies2)or die(mysql_error());
                        echo "Teste01 <br />";

                        if ($dados_ies = mysql_fetch_array($busca_ies2)) {
                            $idies = $dados_ies['id_ies'];
                        }
                        echo "ID IES: $idies<br />";

                        //inserindo localiza��o
                        $inserir_localizacao = "INSERT INTO localizacao(id_localizacao, rua, cidade, numero, uf, campus) VALUES(NULL, '$rua', '$cidade', '$numero', '$estado', '$campus') ";
                        mysql_query($inserir_localizacao) or die(mysql_error());
                        echo "Teste02 <br />";

                        $buscar_localizacao = "SELECT id_localizacao FROM localizacao WHERE rua = '$rua' AND cidade = '$cidade' AND numero = '$numero' AND uf = '$estado' AND campus = '$campus' ";
                        $busca_localizacao = mysql_query($buscar_localizacao)or die(mysql_error());
                        echo "Teste03 <br />";

                        if ($dados_localizacao = mysql_fetch_array($busca_localizacao)) {
                            $idloc = $dados_localizacao['id_localizacao'];
                            $inserir_ies_localizacao = "INSERT INTO ies_localizacao(id_ies, id_localizacao) VALUES('$idies', '$idloc') ";
                            mysql_query($inserir_ies_localizacao) or die(mysql_error());
                            echo "Teste04 <br />";
                        }

                    }
                    elseif ($dados_ies = mysql_fetch_array($busca_ies)){
                        $idies = $dados_ies['id_ies'];    
                    }

                    echo "ID IES: $idies<br />";
                    echo "ID localizacao: $idloc<br />";

                    //inserindo produto
                    $inserir_produto = "INSERT INTO produto_mpec(id_produto, id_dissertacao, id_ies, nome_produto, tema_central, descricao_geral, link_produto, colaborador, avaliacao, downloads, cont_id, situacao) VALUES(NULL, '$iddis', '$idies', '$nome_produto', '$tema', '$descricao', '$link', '$colaborador', 0, 0, '$id_cont', 'Em an�lise') ";
                    mysql_query($inserir_produto) or die(mysql_error());

                    $buscar_produto = "SELECT id_produto FROM produto_mpec WHERE id_dissertacao = '$iddis' AND id_ies = '$idies' AND cont_id = '$id_cont' ";
                    $busca_produto = mysql_query($buscar_produto)or die(mysql_error());

                    if($dados_produto = mysql_fetch_array($busca_produto)){
                        $idprod = $dados_produto['id_produto'];
                    }

                    echo "ID Produto: $idprod<br />";

                    //associando produto ao autor
                    $inserir_esta_associado = "INSERT INTO esta_associado(id_pessoa, id_produto) VALUES('$idau', '$idprod') ";
                    mysql_query($inserir_esta_associado) or die(mysql_error());

                    //inserindo serie de destino
                    if($serie == 'todosp'){
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 13) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '1� Ano Ensino Fundamental') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 1) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '2� Ano Ensino Fundamental') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 2) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '3� Ano Ensino Fundamental') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 3) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '4� Ano Ensino Fundamental') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 4) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '5� Ano Ensino Fundamental') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 5) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '6� Ano Ensino Fundamental') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 6) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '7� Ano Ensino Fundamental') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 7) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '8� Ano Ensino Fundamental') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 8) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '9� Ano Ensino Fundamental') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 9) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '1� Ano Ensino M�dio') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 10) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '2� Ano Ensino M�dio') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 11) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }
                    elseif ($serie == '3� Ano Ensino M�dio') {
                        $inserir_serie = "INSERT INTO serie_produto(id_produto, id_serie) VALUES('$idprod', 12) ";
                        mysql_query($inserir_serie) or die(mysql_error());
                    }

                    //inserindo nivel de ensino
                    if($nivel == 'Ensino Fundamental (Anos Iniciais)'){
                        $inserir_nivel = "INSERT INTO nivel_produto(id_nivel, id_produto) VALUES(2,'$idprod') ";
                        mysql_query($inserir_nivel) or die(mysql_error());
                    }
                    elseif ($nivel == 'Ensino Fundamental (Anos Finais)'){
                        $inserir_nivel = "INSERT INTO nivel_produto(id_nivel, id_produto) VALUES(3,'$idprod') ";
                        mysql_query($inserir_nivel) or die(mysql_error());
                    }
                    elseif ($nivel == 'Ensino M�dio'){
                        $inserir_nivel = "INSERT INTO nivel_produto(id_nivel, id_produto) VALUES(4,'$idprod') ";
                        mysql_query($inserir_nivel) or die(mysql_error());
                    }
                    elseif ($nivel == 'E.J.A'){
                        $inserir_nivel = "INSERT INTO nivel_produto(id_nivel, id_produto) VALUES(5,'$idprod') ";
                        mysql_query($inserir_nivel) or die(mysql_error());
                    }
                    elseif ($nivel == 'Ensino Superior'){
                        $inserir_nivel = "INSERT INTO nivel_produto(id_nivel, id_produto) VALUES(6,'$idprod') ";
                        mysql_query($inserir_nivel) or die(mysql_error());
                    }
                    elseif ($nivel == 'todosn'){
                        $inserir_nivel = "INSERT INTO nivel_produto(id_nivel, id_produto) VALUES(1,'$idprod') ";
                        mysql_query($inserir_nivel) or die(mysql_error());
                    }

                    //inserindo area de concentra��o
                    if($area_concentracao == 'Todas'){
                        $inserir_area_concentracao = "INSERT INTO associado(id_produto, id_areaconc) VALUES('$idprod', 1) ";
                        mysql_query($inserir_area_concentracao) or die(mysql_error());
                    }
                    elseif ($area_concentracao == 'F�sica'){
                        $inserir_area_concentracao = "INSERT INTO associado(id_produto, id_areaconc) VALUES('$idprod', 2) ";
                        mysql_query($inserir_area_concentracao) or die(mysql_error());
                    }
                    elseif ($area_concentracao == 'Qu�mica'){
                        $inserir_area_concentracao = "INSERT INTO associado(id_produto, id_areaconc) VALUES('$idprod', 3) ";
                        mysql_query($inserir_area_concentracao) or die(mysql_error());
                    }
                    elseif ($area_concentracao == 'Biologia'){
                        $inserir_area_concentracao = "INSERT INTO associado(id_produto, id_areaconc) VALUES('$idprod', 4) ";
                        mysql_query($inserir_area_concentracao) or die(mysql_error());
                    }*/


                    /*$inserir_query = "INSERT INTO Novo_Produto(cont_id, id_novoproduto, nome_autor, email_autor, lattes, nome_orientador, nome_coorientador, titulo_dissertacao, data_defesa, resumo_dissertacao, palavra_chave, nome_produto, tema_produto, descricao_geral, link_produto, colaborador, area_concentracao, nivel_ensino, serie_destino, categoria, status) VALUES ('$id_cont', NULL , '$nome_autor', '$email_autor', '$lattes', '$orientador', '$coorientador', '$titulo', '$data', '$resumo', '$palavra', '$nome_produto', '$tema', '$descricao', '$link', '$colaborador', '$area', '$nivel', '$serie', '$categoria', '$status') ";
                    mysql_query($inserir_query) or die(mysql_error());*/

                    ?>
                    <div class="page-header" align="center">
                        <p>Submiss�o finalizada com sucesso!</p>
                        <a href="submeter.html" class="btn btn-primary">Submeter um novo produto</a><br \>
                    </div>
                </div>
            </div>
        </div>

    </body>

    </html>

