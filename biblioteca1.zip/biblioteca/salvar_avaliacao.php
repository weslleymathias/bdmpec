<?php
session_start();
error_reporting(0);
echo file_get_contents('acessoacervo_avaliacao.html');
setlocale(LC_ALL,'pt_BR.latin1');
mb_internal_encoding('latin1'); 
mb_regex_encoding('latin1');

$hostdb = "localhost";// Geralmente Localhost
$userdb = "weslley";//usuário do seu banco de dados
$passdb = "admin";// senha do banco de dados
$tabledb = "biblioteca";// tabela do banco de dados 

/* $hostdb = "mysql.hostinger.com.br";// Geralmente Localhost
$userdb = "u756949596_admin";//usuário do seu banco de dados
$passdb = "admin1";// senha do banco de dados
$tabledb = "u756949596_bibli";// tabela do banco de dados */

$conecta = mysql_connect($hostdb, $userdb, $passdb) or die (mysql_error());
@mysql_select_db($tabledb, $conecta) or die ("Erro ao conectar com o banco de dados");
mysql_set_charset('latin1', $conecta);

$resp1 = $_POST['quest1'];
$resp2 = $_POST['quest2'];
$resp3 = $_POST['quest3'];
$resp4 = $_POST['quest4'];
$resp5 = $_POST['quest5'];
$resp6 = $_POST['quest6'];
$resp7 = $_POST['quest7'];
$resp8 = $_POST['quest8'];
$resp9 = $_POST['quest9'];
$resp10 = $_POST['quest10'];
$resp11 = $_POST['quest11'];
$resp12 = $_POST['quest12'];
$resp13 = $_POST['quest13'];
$resp14 = $_POST['quest14'];
$resp15 = $_POST['quest15'];
$resp16 = $_POST['quest16'];
$resp17 = $_POST['quest17'];
$resp18 = $_POST['quest18'];
$idprod = $_SESSION['IdProd'];
$avaid = $_SESSION['AvaliadorId'];
$email = $_SESSION['UsuarioEmail'];
$senha = $_SESSION['UsuarioSenha'];

/*$busca_query = "SELECT id_produto FROM produto_mpec, usu_avaliador WHERE '$email' = usu_email AND '$senha' = usu_senha";
$busca = mysql_query($busca_query) or die(mysql_error());
while ($dados = mysql_fetch_array($busca)) {  
	$idprod = $dados[id_produto];
	echo "$dados[id_produto]";
}*/

$inserir_query = "INSERT INTO resposta(Resposta01, Resposta02, Resposta03,Resposta04,Resposta05,Resposta06,Resposta07,Resposta08,Resposta09,Resposta10,Resposta11,Resposta12,Resposta13,Resposta14,Resposta15,Resposta16,Resposta17,Resposta18,Id_Produto, data_gravacao, ava_id) VALUES ('$resp1', '$resp2', '$resp3','$resp4','$resp5','$resp6','$resp7','$resp8','$resp9','$resp10','$resp11','$resp12','$resp13','$resp14','$resp15','$resp16','$resp17','$resp18','$idprod', now(), '$avaid')";
mysql_query($inserir_query) or die(mysql_error());
$inserir_query2 = "INSERT INTO avalia(Id_Produto, ava_id) VALUES ('$idprod','$avaid')";
mysql_query($inserir_query2) or die(mysql_error());

?>