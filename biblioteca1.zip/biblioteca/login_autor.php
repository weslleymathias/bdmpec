<?php

error_reporting(0);

include "mysqlconecta.php";

$Email = $_POST['email'];

$busca_query = mysql_query("SELECT nome_autor, email_autor FROM autor WHERE autor.email_autor = '$Email'")or die(mysql_error()); 
if (mysql_num_rows($busca_query) == 0) { //Se nao achar nada, lan�a essa mensagem
  echo file_get_contents('login_autor.html');
  echo "<div class=\"page-header\" align=\"center\">
  <font color=\"red\"><p><b>Email inv�lido. Insira um email existente!</b></font><br \>
  </div>";     
  echo "<hr>";
} 
if ($dados = mysql_fetch_array($busca_query)) {
 if($dados['email_autor'] != NULL){
   $resultado = mysql_fetch_assoc($busca_query);
   if (!isset($_SESSION)) session_start();
	// Salva os dados encontrados na sess�o
   $_SESSION['UsuarioNome'] = $dados['nome_autor'];
   $_SESSION['UsuarioEmail'] = $dados['email_autor'];
   // echo " $_SESSION[UsuarioEmail]";
   // echo " $_SESSION[UsuarioSenha]";
   echo "<script>location.href='area_autor.php';</script>";
  // header ("location: Area_Autor.html");
}
}
?>