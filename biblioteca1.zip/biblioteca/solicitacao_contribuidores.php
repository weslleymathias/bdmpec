<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" type="text/css" href="css/Area_Administra��o.css">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Solicita��es de Novos Contribuidores Pendentes</title>

  <!-- Bootstrap Core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="css/logo-nav.css" rel="stylesheet">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

      </head>

      <body>

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
          <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="#">
                <img src="img/logompec.png" alt="">
              </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav">
                <li><a href='solicitacao_administradores.php'><span>Solicita��es Pendentes</span></a></li>
                <li><a href='administradores.html'><span>Administradores</span></a></li>
                <li><a href='avaliadores_cadastrados.php'><span>Avaliadores</span></a></li>
                <li><a href='avaliacoes.php'><span>Avalia��es</span></a></li>
                <li><a href='contribuidores_cadastrados.php'><span>Contribuidores</span></a></li> 
                <li><a href='revisao.html'><span>M�dulo de Revis�o</span></a></li> 
                <li><a href='#'><span>Dados Estat�sticos</span></a></li>
                <li><a href='index.html'><span>Sair</span></a></li>
              </ul>
            </div>
            <!-- /.navbar-collapse -->
          </div>
          <!-- /.container -->
        </nav>


        <div class="container">
          <div class="row">

            <div class="col-lg-12">
              <legend>�rea Administrativa: Solicita��es de Novos Contribuidores Pendentes<span class="pull-right label label-default">:)</span></legend>

<?php
error_reporting(0);


include "mysqlconecta.php";

$busca_query = mysql_query("SELECT * FROM novo_contribuidor")or die(mysql_error());

if (mysql_num_rows($busca_query) == 0) { //Se nao achar nada, lan�a essa mensagem
  echo "<div class=\"page-header\" align=\"center\">
  <p><b>N�o h� solicita��es de novos contribuidores.</b><br \>
  <a href=\"solicitacao_administradores.php\" class=\"btn btn-primary\">Voltar</a></p><br \>
  </div>";
}

require_once("phpmailer/class.phpmailer.php");

define('GUSER', 'bdmpec@iceb.ufop.br'); // <-- Insira aqui o seu GMail
define('GPWD', 'wgatTpcWCpUjyQ9');    // <-- Insira aqui a senha do seu GMail

function smtpmailer($para, $de, $de_nome, $assunto, $corpo) { 
  global $error;
  $mail = new PHPMailer();
  $mail->IsSMTP();    // Ativar SMTP
  $mail->SMTPDebug = 0;   // Debugar: 1 = erros e mensagens, 2 = mensagens apenas
  $mail->SMTPAuth = true;   // Autentica��o ativada
  $mail->SMTPSecure = 'tls';  // SSL REQUERIDO pelo GMail
  $mail->Host = 'smtp.ufop.br'; // SMTP utilizado
  $mail->Port = 25;     // A porta 587 dever� estar aberta em seu servidor
  $mail->Username = GUSER;
  $mail->Password = GPWD;
  $mail->SetFrom($de, $de_nome);
  $mail->Subject = $assunto;
  $mail->Body = $corpo;
  $mail->AddAddress($para);
  if(!$mail->Send()) {
    $error = 'Mail error: '.$mail->ErrorInfo; 
    return false;
  } else {
    $error = 'Mensagem enviada!';
    return true;
  }
}

echo "<div class=\"container\">
<div class=\"row\">

<div class=\"col-lg-12\">";

while ($dados = mysql_fetch_array($busca_query)) {
	//echo "ID: $dados[0] <br />";
  echo "Nome: $dados[1] <br />"; 
  echo "IES: $dados[2]<br />";
  echo "Curso: $dados[3]<br />";
  echo "Email: $dados[4] <br />"; 
  echo "Lattes: $dados[5]<br />";
//  echo "Senha: $dados[6]<br />";
  $idava = $dados[0];
  $nomeava = $dados[1];
  $iesava = $dados[2];
  $cursoava = $dados[3];
  $emailava = $dados[4];
  $lattesava = $dados[5];
  $senhaava = $dados[6];

  echo "<form method=post>
  <button type=\"submit\" class=\"btn btn-danger\" name=\"Recusar\" id=\"Recusar\" value=\"Recusar\"><span class=\"glyphicon glyphicon-remove\"></span> Recusar</button>
  <input type=\"hidden\" class=\"form-control\" name=\"idava\" id=\"idava\" value=\"$idava\"required>
  <input type=\"hidden\" class=\"form-control\" name=\"emailava\" id=\"emailava\" value=\"$emailava\"required>
  <input type=\"hidden\" class=\"form-control\" name=\"nomeava\" id=\"nomeava\" value=\"$nomeava\"required>
  <input type=\"hidden\" class=\"form-control\" name=\"iesava\" id=\"iesava\" value=\"$iesava\"required>
  <input type=\"hidden\" class=\"form-control\" name=\"cursoava\" id=\"cursoava\" value=\"$cursoava\"required>
  <input type=\"hidden\" class=\"form-control\" name=\"lattesava\" id=\"lattesava\" value=\"$lattesava\"required>
  <input type=\"hidden\" class=\"form-control\" name=\"senhaava\" id=\"senhaava\" value=\"$senhaava\"required>
  <button type=\"submit\" class=\"btn btn-success\" name=\"Aceitar\" id=\"Aceitar\" value=\"Aceitar\"><span class=\"glyphicon glyphicon-ok\"></span> Aceitar</button>
  </form>";
}
  if(isset($_POST['Recusar'])){
    $_SESSION['idava'] = $_POST['idava'];
    $_SESSION['emailava'] = $_POST['emailava'];
    $_SESSION['nomeava'] = $_POST['nomeava'];
    $_SESSION['iesava'] = $_POST['iesava'];
    $_SESSION['cursoava'] = $_POST['cursoava'];
    $_SESSION['lattesava'] = $_POST['lattesava'];
    $_SESSION['senhaava'] = $_POST['senhaava'];

    $Vai = "Ol� $_POST[nomeava],\n\nSua solicita��o para se tornar um contribuidor da BDMPEC foi negada.\nVerifique os dados abaixo e note se h� algo que n�o esteja de acordo com o que foi estabelecido no formul�rio e tente novamente.\n\nNome: $_POST[nomeava]\n\nIES: $_POST[iesava]\n\nCurso: $_POST[cursoava]\n\nEmail: $_POST[emailava]\n\nLattes: $_POST[lattesava]\n\nSenha: $_POST[senhaava]\n\nAdministra��o BDMPEC";
    if (smtpmailer($_POST['emailava'], 'bdmpec@iceb.ufop.br', 'BDMPEC', 'Solicita��o BDMPEC', $Vai)) {
      $deletar_query = "DELETE FROM novo_contribuidor WHERE Id_novocontribuidor = $_POST[idava]";
      mysql_query($deletar_query) or die(mysql_error());
      echo "<script>location.href='finalizar_recusar_contribuidor.php';</script>";
    }

  } elseif (isset($_POST['Aceitar'])) {
    $_SESSION['idava'] = $_POST['idava'];
    $_SESSION['emailava'] = $_POST['emailava'];
    $_SESSION['nomeava'] = $_POST['nomeava'];
    $_SESSION['iesava'] = $_POST['iesava'];
    $_SESSION['cursoava'] = $_POST['cursoava'];
    $_SESSION['lattesava'] = $_POST['lattesava'];
    $_SESSION['senhaava'] = $_POST['senhaava'];

      $Vai = "Ol� $_POST[nomeava],\n\nSua solicita��o para se tornar um contribuidor da BDMPEC foi conclu�da com sucesso.\nVerifique os dados abaixo e j� pode come�ar a utilizar seu perfil na BDMPEC.\n\nNome: $_POST[nomeava]\n\nIES: $_POST[iesava]\n\nCurso: $_POST[cursoava]\n\nEmail: $_POST[emailava]\n\nLattes: $_POST[lattesava]\n\nSenha: $_POST[senhaava]\n\nAdministra��o BDMPEC";
      if (smtpmailer($_POST['emailava'], 'bdmpec@iceb.ufop.br', 'BDMPEC', 'Solicita��o BDMPEC', $Vai)) {
        $inserir_query = "INSERT INTO usu_contribuidor(cont_id, cont_nome, cont_senha, cont_ies, cont_curso, cont_email, cont_lattes) VALUES (NULL, '$_POST[nomeava]', '$_POST[senhaava]', '$_POST[iesava]', '$_POST[cursoava]', '$_POST[emailava]', '$_POST[lattesava]')";
        mysql_query($inserir_query) or die(mysql_error());
        $deletar_query = "DELETE FROM novo_contribuidor WHERE Id_novocontribuidor = $_POST[idava]";
        mysql_query($deletar_query) or die(mysql_error());
        echo "<script>location.href='finalizar_aceitar_contribuidor.php';</script>";
      }
  }
  echo "<hr>";

echo "</div>
</div>
</div>";

?>

</body>
</html>