<?php
error_reporting(0);
//{
echo file_get_contents('Acesso_Acervo.html');
//}

setlocale(LC_ALL,'pt_BR.latin1');
mb_internal_encoding('latin1'); 
mb_regex_encoding('latin1');

include "mysqlconecta.php";


$fisica = "verdadeiro";
$quimica = "verdadeiro";
$biologia = "verdadeiro";


$busca = $_POST['palavra'];// palavra que o usuario digitou
$tipo = $_POST['tipo'];
$area = $_POST['area'];
$categoria = $_POST['categoria'];
$nivel = $_POST['nivel'];
$ano = $_POST['ano'];

echo "1<br />";
echo "2<br />";
echo "3<br />";
echo "4<br />";
echo "5<br />";
echo "6<br />";
echo "7<br />";
echo "8<br />";
echo "9<br />";
echo "10<br />";


?>