<html>
<head>
	<title></title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
	<?php 
	error_reporting(0);

	include "mysqlconecta.php";

	$Nome = $_POST['nome'];
	$Email = $_POST['email'];
	$IES = $_POST['ies'];
	$Curso = $_POST['curso'];
	$Lattes = $_POST['lattes'];
	$Senha = $_POST['senha'];
	$assunto = 'Novo avaliador';
	$de = $_POST['email'];

	$inserir_query = "INSERT INTO novo_contribuidor(Id_novocontribuidor, Nome, IES, Curso, Email, Lattes, Senha) VALUES (NULL, '$Nome', '$IES', '$Curso', '$Email', '$Lattes', '$Senha')";
	mysql_query($inserir_query) or die(mysql_error());

/*$Nome = "Nome: ".$_POST['nome']." \n";
$Email = "Email: ".$_POST['email']." \n";
$IES = "IES: ".$_POST['ies']." \n";
$Curso = "Curso ou Programa da IES:". $_POST['curso'];
$Lattes = "Lattes: ".$_POST['lattes']." \n";
$Senha = "Senha: ".$_POST['senha']." \n";
$assunto = 'Novo avaliador';
$de = $_POST['email'];*/


$Vai = "$Nome\n\n$Email\n\n$IES\n\n$Curso\n\n$Lattes\n";

require_once("phpmailer/class.phpmailer.php");

define('GUSER', 'bdmpec@iceb.ufop.br'); // <-- Insira aqui o seu GMail
define('GPWD', 'wgatTpcWCpUjyQ9');    // <-- Insira aqui a senha do seu GMail

function smtpmailer($para, $de, $de_nome, $assunto, $corpo) { 
  global $error;
  $mail = new PHPMailer();
  $mail->IsSMTP();    // Ativar SMTP
  $mail->SMTPDebug = 0;   // Debugar: 1 = erros e mensagens, 2 = mensagens apenas
  $mail->SMTPAuth = true;   // Autentica��o ativada
  $mail->SMTPSecure = 'tls';  // SSL REQUERIDO pelo GMail
  $mail->Host = 'smtp.ufop.br'; // SMTP utilizado
  $mail->Port = 25;     // A porta 587 dever� estar aberta em seu servidor
  $mail->Username = GUSER;
  $mail->Password = GPWD;
  $mail->SetFrom($de, $de_nome);
  $mail->Subject = $assunto;
  $mail->Body = $corpo;
  $mail->AddAddress($para);
  if(!$mail->Send()) {
    $error = 'Mail error: '.$mail->ErrorInfo; 
    return false;
  } else {
    $error = 'Mensagem enviada!';
    return true;
  }
}

if (smtpmailer('bdmpec@iceb.ufop.br', $de, $Nome, $assunto, $Vai)) {
	echo "<script>location.href='finalizar_cadastro_contribuidor.php';</script>";
	
}
if (!empty($error)) echo $error;

/*

echo '<p><font face="Tahoma" color="##000000"><span style="font-size:11pt;"><b>Sua mensagem foi 
enviada com sucesso!</b></span></font></p>';

echo '<font face="Tahoma" color="##000000"><span style="font-size:10pt;">Em breve 
entraremos em contato com voc�! Obrigado! </span></font></p>';
*/
?>
</body>
</html>